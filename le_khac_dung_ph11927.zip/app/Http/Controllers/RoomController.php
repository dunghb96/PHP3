<?php

namespace App\Http\Controllers;

use App\Http\Requests\RoomFromRequest;
use App\Models\Room;
use App\Models\Room_service;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class RoomController extends Controller
{
    public function index()
    {
        $rooms = Room::latest()->paginate(5);
        return view('admin.room.index', compact('rooms'));
    }
    public function add()
    {
        $services = Service::all();
        return view('admin.room.add', compact('services'));
    }
    public function addNew(RoomFromRequest $request)
    {
        $model = new Room();
        $model->fill($request->all());
        if ($request->hasFile('image')) {
            $path = $request->file('image')->storeAs('public/uploads/rooms', uniqid() . '-' . $request->image->getClientOriginalName());
            $model->image = str_replace('public/', '', $path);
        }
        $model->save();
        if ($request->service_id) {
            foreach ($request->service_id as $key => $value) {
                $dataCreated = [
                    'room_id' => $model->id,
                    'service_id' => $value,
                    'additional_price' => $request->additional_price[$key],
                ];
                Room_service::create($dataCreated);
            }
        }
        return redirect()->route('room.list');
    }
    public function edit($id)
    {
        $services = Service::all();
        $room = Room::find($id);
        $room_service = Room_service::where('room_id', $id)->get();
        return view('admin.room.edit', compact('room', 'services', 'room_service'));
    }
    public function saveEdit($id, RoomFromRequest $request)
    {
        $model = Room::find($id);
        $path_image = 'storage/' . $model->image;
        if (file_exists($path_image)) {
            unlink($path_image);
        }
        $model->fill($request->all());
        if ($request->hasFile('image')) {
            $path = $request->file('image')->storeAs('public/uploads/rooms', uniqid() . '-' . $request->image->getClientOriginalName());
            $model->image = str_replace('public/', '', $path);
        }
        $model->save();
        if ($request->service_id) {
            Room_service::where('room_id', $id)->delete();
            foreach ($request->service_id as $key => $value) {
                $dataUpdateServiceRoom = [
                    'room_id' => $id,
                    'service_id' => $value,
                    'additional_price' => $request->additional_price[$key],
                ];
                Room_service::create($dataUpdateServiceRoom);
            }
        }
        return redirect()->route('room.list');
    }
    public function remove($id)
    {
        $model = Room::find($id);
        if (!$model) {
            return redirect()->back();
        }
        $path_image = 'storage/' . $model->image;
        if (file_exists($path_image)) {
            unlink($path_image);
        }
        Room_service::where('room_id', $id)->delete();
        $model->delete();
        return redirect()->back();
    }
}
