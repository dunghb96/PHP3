<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Room extends Model
{
    use HasFactory;
    protected $table='rooms';
    protected $guarded = [];
    public $fillable = [
        'room_no', 'image', 'floor', 'price', 'detail'
    ];
    public function room_service(){
        return $this->hasMany(Room_service::class,'room_id');
    }
}
